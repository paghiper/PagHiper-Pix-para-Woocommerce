<?php
/*
* @package    PagHiper Pix Woocommerce
* @version    1.0
* @license    BSD License (3-clause)
* @copyright  (c) 2020
* @link       https://www.paghiper.com/
* @dev        Bruno Alencar - Loja5.com.br
*/
include("../../../wp-load.php");
wp_redirect('../../../index.php');
?>